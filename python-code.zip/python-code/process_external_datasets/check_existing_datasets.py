from dataop import *
from to_file import *

if __name__ == "__main__":
    all_dataset_names = sorted_by_increasing_size(get_all_datasets_names())
    nb_datasets = len(all_dataset_names)

    cpt = 0
    for ds_name in all_dataset_names:
        cpt += 1
        print(f'Analyzing #{cpt}/#{nb_datasets} CLASS dataset {ds_name}...')
        df_type = my_from_csv(get_dataset_feature_type_list(ds_name))
        unique_types = df_type[FEATURE_TYPE_COLUMN_NAME].unique()
        print(f'--> List of feature types: {unique_types}')
        if 'Date' in unique_types:
            print(f'--> (!) Date in one of the features')
