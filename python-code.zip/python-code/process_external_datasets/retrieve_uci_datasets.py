import os

from ucimlrepo import fetch_ucirepo, list_available_datasets
import pandas as pd
import numpy as np

from constants import *
from dataop import my_to_csv


# If categorical or binary, use drastic distance, if a value determined by ?
# If continuous, use value difference
# When computing a distance between i and j, if j is positive return the distance, otherwise, return diameter - distance
# diameter is the max possible distance

# Everything should be normalized to, let's say 100

# We took all datasets available and for binary classification
# Exceptions:
# - Dataset 357 'Occupancy Detection': there are some target values at Nan
# - Dataset 20 'Census Income', 857 'Risk Factor', 32 'Cylinder Bands': inconsistencies between declared type and actual values

def map_target_values(value1, value2):
    """Maps the two target values to {0, 1} based on specific rules."""
    try:
        # Attempt to convert values to float to check if they are numeric
        float_val1, float_val2 = float(value1), float(value2)
        if {float_val1, float_val2} == {0.0, 1.0}:
            return (0, 1) if float_val1 < 0.5 else (1, 0)
    except ValueError:
        # If conversion to float fails, they are non-numeric
        pass

    lower_val1 = str(value1).lower()
    lower_val2 = str(value2).lower()

    # Case 1: Values are already {0, 1}
    if {lower_val1, lower_val2} == {'0', '1'}:
        return value1, value2
    # Case 2: Values are '-' and '+'
    elif {lower_val1, lower_val2} == {'-', '+'}:
        return (0, 1) if lower_val2 == '+' else (1, 0)
    # Case 3: Values are 'yes' and 'no'
    elif {lower_val1, lower_val2} == {'yes', 'no'}:
        return (1, 0) if lower_val1 == 'yes' else (0, 1)
    # Case 4: One value is the other prefixed with 'no' or 'no-'
    elif lower_val1.startswith('no') or lower_val2.startswith('no'):
        assert not lower_val1.startswith('no') or not lower_val2.startswith('no')
        return (0, 1) if lower_val1.startswith('no') else (1, 0)
    # Case 5: Values are 'positive' and 'negative'
    elif {lower_val1, lower_val2} == {'positive', 'negative'}:
        return (1, 0) if lower_val1 == 'positive' else (0, 1)
    # Case 6: Values are 't' and 'f'
    elif {lower_val1, lower_val2} == {'t', 'f'}:
        return (1, 0) if lower_val1 == 't' else (0, 1)
    # Case 6: Values are 't' and 'f'
    elif {lower_val1, lower_val2} == {'true', 'false'}:
        return (1, 0) if lower_val1 == 'true' else (0, 1)
    # Case 8: Values are 'n' and 'o'
    elif {lower_val1, lower_val2} == {'n', 'o'}:
        return (1, 0) if lower_val1 == 'o' else (0, 1)
    # Default case: Map to {0, 1} arbitrarily
    else:
        return 0, 1


if __name__ == "__main__":
    # check which datasets can be imported
    list_of_available_datasets = list_available_datasets()


    #list_of_available_datasets = [13, 14, 15, 16, 17, 22, 27, 28, 43, 46, 47, 52, 70, 73, 74, 75, 88, 94, 95, 96, 101, 105, 117, 143, 144, 145, 151, 159, 161, 172, 174, 176, 222, 225, 229, 244, 264, 267, 277, 300, 327, 329, 350, 365, 367, 372, 380, 419, 426, 451, 468, 519, 529, 537, 545, 560, 563, 565, 572, 722, 728, 732, 759, 827, 848, 850, 887, 890, 891, 915, 967]
    #list_of_available_datasets = [22]
    # Define root path for saving datasets
    path_root = os.environ[DATASET_ROOT_PATH_ENV_VAR_NAME] + '/'
    available_datasets = []
    all_feature_types = set()
    all_target_values = set()

    # Define a range of IDs to check for availability
    # Exclusion of id 32, 357 datasets because of too many values to unpack -> this would fail to create our csv file
    # Exclusion of id 117 dataset because of wrong declaration of feature types (some declared integers have string values)
    # Exclusion of id 967 dataset which is way too large (235795 rows / 54 features)
    # Exclusion of id 891 and 367 datasets which takes too much time for existing models to proceed (more than 3h for each sampling)
    # Exclusion of id 560 and 222 datasets which have an attribute Date
    #for dataset_id in range(0, 1200):
    ds_ids = [13, 14, 15, 16, 17, 22, 27, 28, 43, 46, 47, 52, 70, 73, 74, 75, 88, 94, 95, 96, 101, 105, 143, 144, 145,
              151, 161, 172, 174, 176, 225, 244, 267, 277, 300, 327, 329, 380, 419, 426, 451, 468, 519, 529, 537, 545,
              563, 565, 572, 603, 728, 732, 759, 850, 857, 887, 890, 915]
    for dataset_id in ds_ids:
        if dataset_id in [32, 117, 222, 357, 367, 560, 891, 967]:
            continue
        print(f'Current number of valid datasets: {len(available_datasets)}')
        try:
            # Try to fetch the dataset
            uci_dataset = fetch_ucirepo(id=dataset_id)

            # Extract the feature data
            features_df = uci_dataset.data.features.copy()
            if not isinstance(features_df, pd.DataFrame):
                features_df = pd.DataFrame(features_df)

            # Handle missing values explicitly
            missing_values_symbol = uci_dataset.metadata.missing_values_symbol
            if missing_values_symbol:
                features_df.replace(missing_values_symbol, np.nan, inplace=True)

            # Extract the target column information
            target_cols = uci_dataset.metadata.target_col
            if isinstance(target_cols, list) and len(target_cols) == 1:
                target_column = target_cols[0]
                target_values = uci_dataset.data.targets.copy()

                # Convert target values to a pandas DataFrame
                target_df = pd.DataFrame(target_values, columns=[target_column])

                # Handle missing values in the target column
                # Handle missing values in the target column
                if missing_values_symbol is not None:
                    target_df.replace(missing_values_symbol, np.nan, inplace=True)
                else:
                    # Check if `None` itself might represent missing values
                    target_df.replace([None], np.nan, inplace=True)

                # Combine features and target into a single DataFrame
                pd_dataset = pd.concat([features_df, target_df], axis=1)

                # Determine if the dataset is binary by checking the number of unique target values
                nb_unique_values = target_df[target_column].nunique()
                if nb_unique_values == 2:
                    # Store the dataset if it meets the criteria
                    available_datasets.append((dataset_id, pd_dataset))

                    # Get the name, number of rows, and number of features
                    dataset_name = uci_dataset.metadata.name
                    nb_rows = pd_dataset.shape[0]
                    nb_features = pd_dataset.shape[1] - 1  # Exclude target column

                    # Create a directory of name dataset_name and save the base dataset CSV file
                    dataset_filename = f'{dataset_id}-{dataset_name}_{nb_rows}r_{nb_features}f'
                    dataset_directory = os.path.join(path_root, dataset_filename)
                    os.makedirs(dataset_directory, exist_ok=True)
                    base_file_path = os.path.join(dataset_directory, dataset_filename)
                    my_to_csv(pd_dataset, base_file_path + DATASET_ORIGINAL + '.csv', with_index=True)

                    # Initialize lists to store feature names and types
                    feature_names = []
                    feature_types = []

                    # Create a mapping for feature names
                    feature_name_mapping = {}

                    # Iterate over the variables and filter out only the features
                    for var_name, role in uci_dataset.variables.role.items():
                        if role == 'Feature':
                            feature_names.append(f"X_{len(feature_names) + 1}")
                            feature_types.append(uci_dataset.variables.type.get(var_name, 'Unknown'))
                            feature_name_mapping[var_name] = f"X_{len(feature_names)}"
                    # Update the DataFrame column names based on the mapping
                    pd_dataset.rename(columns=feature_name_mapping, inplace=True)

                    # Ensure that the lengths of feature names and feature types match
                    if len(feature_names) == len(feature_types):
                        # Save feature types information
                        feature_type_df = pd.DataFrame({
                            FEATURE_NAME_COLUMN_NAME: feature_names,
                            FEATURE_TYPE_COLUMN_NAME: feature_types
                        })
                        my_to_csv(feature_type_df, base_file_path + DATASET_TYPE + '.csv', with_index=False)
                    else:
                        print(
                            f"Warning: The number of feature names ({len(feature_names)}) does not match the number of feature types ({len(feature_types)}) for Dataset ID {dataset_id}. Skipping type file creation.")

                    # Create formatted dataset with renamed columns
                    formatted_df = pd_dataset.copy()
                    formatted_df.rename(columns={target_column: 'y'}, inplace=True)
                    formatted_df.columns = feature_names + ['y']
                    #formatted_filename = f"{dataset_name}_{nb_rows}r_{nb_features}f-formatted.csv"
                    #formatted_file_path = path_root + formatted_filename
                    #my_to_csv(formatted_df, formatted_file_path, with_index=True)

                    # Create the -formatted2.csv file by mapping target values to {0, 1}
                    print(formatted_df['y'].unique())
                    v1, v2 = formatted_df['y'].unique()

                    print(map_target_values(v1, v2))
                    mapped_v1, mapped_v2 = map_target_values(v1, v2)

                    print(f'*** Values ({v1}, {v2}) --- mapped to ---> ({mapped_v1}, {mapped_v2}) ***')
                    formatted2_df = formatted_df.copy()
                    formatted2_df['y'] = formatted2_df['y'].replace({v1: mapped_v1, v2: mapped_v2})
                    #formatted2_filename = f"{dataset_name}_{nb_rows}r_{nb_features}f-formatted2.csv"
                    #formatted2_file_path = path_root + formatted2_filename

                    # The last step is to convert all binary / categorical / date into integers
                    #for _, row in feature_type_df.iterrows():
                    #    feature_name = row[FEATURE_NAME_COLUMN_NAME]
                    #    feature_type = row[FEATURE_TYPE_COLUMN_NAME]
                    #
                    #    if feature_type in ['Binary', 'Categorical', 'Date']:
                    #        unique_values = formatted2_df[feature_name].dropna().unique()
                    #        value_mapping = {val: i for i, val in enumerate(unique_values)}
                    #        formatted2_df[feature_name] = formatted2_df[feature_name].map(value_mapping).astype(
                    #            pd.Int64Dtype())

                    my_to_csv(formatted2_df, base_file_path + '.csv', with_index=True)

                    # Update the set of all encountered feature types and target values
                    all_feature_types.update(feature_types)
                    all_target_values.update(formatted_df['y'].unique())
                    #list_of_available_datasets.append(dataset_id)

                    print(
                        f"Dataset ID {dataset_id} ({uci_dataset.metadata.name}) is available and can be used for binary classification "
                        f"(target name = {target_column}, size output domain {nb_unique_values})")
                    if uci_dataset.metadata.has_missing_values:
                        print(
                            f"Dataset ID {dataset_id} ({uci_dataset.metadata.name}) has missing values with symbol {uci_dataset.metadata.missing_values_symbol}.")
                    print(f'Target name: {target_column}, target values: {set(target_df[target_column])}')
                else:
                    print(
                        f"Dataset ID {dataset_id} ({uci_dataset.metadata.name}) is available but does not have exactly two unique target values "
                        f"(target name = {target_column}, {set(target_df[target_column])}, size output domain {nb_unique_values}).")
            else:
                print(f"Dataset ID {dataset_id} ({uci_dataset.metadata.name}) does not have exactly one target column.")
        except Exception as e:
            # Handle the case where the dataset is not available
            print(f"Dataset ID {dataset_id} is not available: {str(e)}")

    # Print all encountered feature types and target values
    print("Encountered feature types:", all_feature_types)
    print("Encountered target values:", all_target_values)
    #print(f"All available {len(list_of_available_datasets)} datasets: {list_of_available_datasets}")
