Run in the following order:
- process_external_datasets/retrieve_uci_datasets.py: to retrieve all 58 selected datasets from the UCI repository (https://archive.ics.uci.edu/datasets/). All datasets will be imported into the local directory dataset/, whose absolute path must be specified as an environment variable named KRML_DATASETS
- createsamplings.py: to create the samplings for each dataset
- runs/runexistingmodels: to train and test all existing learning models
- runs/createOCFsfortrainingsets.py: to train the improvement-based learning model
- runs/runtests.py: to test the improvement-based learning model
- runs/from_test_results_to_plot_2025: to generate all figures based on the results
