import os
import numpy as np
import pandas as pd
import warnings
import time

from constants import *
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, matthews_corrcoef, roc_auc_score, confusion_matrix
from sklearn.impute import SimpleImputer

from custom_models.majority_classifier import MajorityClassifier
from dataop import my_from_csv, save_test_results_into_dataset, sorted_by_increasing_size, my_to_csv, separate_id_x_y
from to_file import *

if __name__ == "__main__":
    #warnings.filterwarnings("ignore", category=UserWarning, module="sklearn.preprocessing._encoders")

    models = {
        MODEL_NAME_LOGISTIC_REGRESSION: LogisticRegression(max_iter=5000),
        MODEL_NAME_SVM: SVC(probability=True),
        MODEL_NAME_DECISION_TREE: DecisionTreeClassifier(),
        MODEL_NAME_RANDOM_FOREST: RandomForestClassifier(),
        MODEL_NAME_GRADIENT_BOOSTING: GradientBoostingClassifier(),
        MODEL_NAME_NEURAL_NETWORK: MLPClassifier(max_iter=5000),
        MODEL_NAME_KNN: KNeighborsClassifier(),
        MODEL_NAME_NAIVE_BAYES: GaussianNB(),
        MODEL_NAME_TRIVIAL_MAJ: MajorityClassifier()
    }

    # Metrics to be calculated
    metrics = ALL_METRIC_NAMES + [METRIC_ROCAUC]

    all_dataset_names = sorted_by_increasing_size(get_all_datasets_names())
    nb_datasets = len(all_dataset_names)

    cpt = 0
    for dataset_name in all_dataset_names:
        cpt += 1
        start_time_all_samplings = time.time()
        print(f'Processing #{cpt}/#{nb_datasets} CLASS dataset {dataset_name}...')

        # Initialize results dictionary
        results = {model: {metric: [] for metric in metrics} for model in models}
        # Initialize for each model the TP/TN/FP/FN to 0
        confusion_results = {model: {'TP': 0, 'TN': 0, 'FP': 0, 'FN': 0} for model in models}

        # List all sampling directories for the corresponding dataset
        all_sampling_directories = get_all_sampling_dir_paths(dataset_name)

        for sampling_dir_name in all_sampling_directories:
            start_time_sampling = time.time()

            id_sampling = get_id_sampling_from_dir_path(sampling_dir_name)

            train_dataset = my_from_csv(get_sampling_train_existingmodel_file_path(dataset_name, id_sampling))
            test_dataset = my_from_csv(get_sampling_test_existingmodel_file_path(dataset_name, id_sampling))
            #print(f'train_dataset:\n{train_dataset}\n')
            #print(f'test_dataset:\n{test_dataset}\n')

            # Separate id, features and y
            _, x_train_dataset, y_train_dataset = separate_id_x_y(train_dataset)
            _, x_test_dataset, y_test_dataset = separate_id_x_y(test_dataset)
            #print(f'x_train_dataset:\n{x_train_dataset}\ny_train_dataset\n:{y_train_dataset}\n')
            #print(f'x_test_dataset:\n{x_test_dataset}\ny_test_dataset\n:{y_test_dataset}\n')

            # Iterate over each model
            for model_name, model in models.items():
                model.fit(x_train_dataset, y_train_dataset)

                # Predict on the test set
                y_prediction = model.predict(x_test_dataset)
                y_proba = model.predict_proba(x_test_dataset)[:, 1] if hasattr(model, 'predict_proba') else None

                # Calculate and store the metrics
                results[model_name][METRIC_ACCURACY].append(accuracy_score(y_test_dataset, y_prediction))
                results[model_name][METRIC_PRECISION].append(precision_score(y_test_dataset, y_prediction, zero_division=0))
                results[model_name][METRIC_RECALL].append(recall_score(y_test_dataset, y_prediction, zero_division=0))
                results[model_name][METRIC_F1_SCORE].append(f1_score(y_test_dataset, y_prediction, zero_division=0))
                results[model_name][METRIC_MCC].append(matthews_corrcoef(y_test_dataset, y_prediction))
                results[model_name][METRIC_JACCARD].append(my_jaccard_index(y_test_dataset, y_prediction))
                results[model_name][METRIC_YOUDEN].append(my_youden_index(y_test_dataset, y_prediction))
                if y_proba is not None and len(np.unique(y_test_dataset)) > 1:  # Check if y_test has more than one class
                    results[model_name][METRIC_ROCAUC].append(roc_auc_score(y_test_dataset, y_proba))
                else:
                    results[model_name][METRIC_ROCAUC].append(np.nan)  # Append NaN for undefined ROC AUC scores

                # Calculate confusion matrix components
                cm = confusion_matrix(y_test_dataset, y_prediction, labels=[0, 1])

                if cm.shape == (2, 2):
                    tn, fp, fn, tp = cm.ravel()
                elif cm.shape == (1, 1) and len(np.unique(y_test_dataset)) == 1:
                    tn, fp, fn, tp = 0, 0, 0, 0
                else:
                    tn, fp, fn, tp = 0, 0, 0, 0
                #print(f"model {model_name}, sampling {sampling_dir_name}, local CM: TP: {tp}, TN: {tn}, FP: {fp}, FN: {fn}")

                confusion_results[model_name]['TP'] += tp
                confusion_results[model_name]['TN'] += tn
                confusion_results[model_name]['FP'] += fp
                confusion_results[model_name]['FN'] += fn

            end_time_sampling = time.time()
            execution_time = end_time_sampling - start_time_sampling
            print(f'---> Processed the SAMPLING dataset {sampling_dir_name} in {execution_time:.0f} seconds')

        # Compute the average of each metric for each model, ignoring NaN values for ROC AUC
        average_results = {
            model: {metric: np.nanmean(scores) if metric == 'roc_auc' else np.mean(scores) for metric, scores in
                    model_results.items()} for model, model_results in results.items()}

        # Print the average results and confusion matrix components and save them in the .csv result file
        for model, metrics in average_results.items():
            dataset_results = {MODEL_NAME: model}
            #print(f"Model: {model}")
            #print(metrics.items())
            for metric, score in metrics.items():
                #print(f"{metric}: {score:.2f}")
                dataset_results[METRIC_NAME_TO_AVG_METRIC_FEATURE_NAME[metric]] = score
            tp, tn, fp, fn = confusion_results[model]['TP'], confusion_results[model]['TN'], confusion_results[model][
                'FP'], confusion_results[model]['FN']
            dataset_results.update({TOTAL_TP: tp, TOTAL_TN: tn, TOTAL_FP: fp, TOTAL_FN: fn})
            #total = tp + tn + fp + fn
            #if total > 0:
            #    accuracy = (tp + tn) / total
            #    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            #    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            #    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
            #else:
            #    accuracy = precision = recall = f1 = 0

            #print(f"Aggregated Confusion Matrix:")
            #print(f"TP: {tp}, TN: {tn}, FP: {fp}, FN: {fn}")

            # We save all resulting tests in a dataset
            save_test_results_into_dataset(get_all_results_file_name(dataset_name), dataset_results)
            #print(f"Accuracy from confusion matrix: {accuracy:.4f}")
            #print(f"Precision from confusion matrix: {precision:.4f}")
            #print(f"Recall from confusion matrix: {recall:.4f}")
            #print(f"F1 Score from confusion matrix: {f1:.4f}")
            #print()

        end_time_all_samplings = time.time()
        execution_time = end_time_all_samplings - start_time_all_samplings
        print(f'**** Time taken for dataset {dataset_name} (all models): {execution_time:.0f} seconds ****')
