import os
import shutil

# Delete all sampling directories in datasets
# Leave the dataset itself and the log file
from to_file import get_all_datasets_names, get_dataset_dir_path, is_sampling_dir_path_name

if __name__ == "__main__":
    all_dataset_names = sorted(get_all_datasets_names())
    # We process each dataset retrieved in all_dataset_names
    all_sampling_directories_for_all_datasets = []
    for dataset_name in all_dataset_names:
        # Delete every sampling directory
        # List all sampling directories for the corresponding dataset
        all_sampling_directories = [os.path.join(get_dataset_dir_path(dataset_name),
                                                               dir_name) for dir_name in os.listdir(get_dataset_dir_path(dataset_name)) if
                                    os.path.isdir(os.path.join(get_dataset_dir_path(dataset_name),
                                                               dir_name)) and is_sampling_dir_path_name(dir_name)]
        all_sampling_directories = sorted(all_sampling_directories)
        all_sampling_directories_for_all_datasets = all_sampling_directories_for_all_datasets + all_sampling_directories

    # Ask for user confirmation
    print("The following directories and their contents will be deleted:")
    for sampling_dir_name in all_sampling_directories_for_all_datasets:
        print(sampling_dir_name)
    confirm = input("Are you sure you want to delete these directories? (y/n): ").strip().lower()
    if confirm == 'y':
        for sampling_dir_name in all_sampling_directories_for_all_datasets:
            if os.path.exists(sampling_dir_name):
                shutil.rmtree(sampling_dir_name)
                print(f"Deleted: {sampling_dir_name}")
            else:
                print(f"Directory not found: {sampling_dir_name}")
    else:
        print("Operation cancelled. No directories were deleted.")


