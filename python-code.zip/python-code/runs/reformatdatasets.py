from dataop import my_from_csv
from to_file import get_dataset_file_path, get_all_datasets_names

if __name__ == "__main__":
    all_dataset_names = get_all_datasets_names()
    print(all_dataset_names)
    for dataset_name in all_dataset_names:
        pd = my_from_csv(get_dataset_file_path(dataset_name), remove_first_column=True)
        pd.to_csv(get_dataset_file_path(dataset_name),index=False)
