import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from math import pi

from dataop import *
from to_file import *

from sklearn.cluster import KMeans

MODEL_SHORT_NAMES = {
    MODEL_NAME_LOGISTIC_REGRESSION: 'LogReg',
    MODEL_NAME_SVM: 'SVM',
    MODEL_NAME_DECISION_TREE: 'DecTree',
    MODEL_NAME_RANDOM_FOREST: 'RandFor',
    MODEL_NAME_GRADIENT_BOOSTING: 'GradBoost',
    MODEL_NAME_NEURAL_NETWORK: 'NeurNet',
    MODEL_NAME_KNN: 'KNN',
    MODEL_NAME_NAIVE_BAYES: 'NaivBay',
    MODEL_NAME_TRIVIAL_MAJ: 'Maj',
    NEW_MODEL_NAME_OCF_HAMMING: 'OCF'
}

NEW_METRIC_NAME_TO_AVG_METRIC_FEATURE_NAME = {
    METRIC_ACCURACY : NEW_AVG_ACCURACY,
    METRIC_PRECISION : NEW_AVG_PRECISION,
    METRIC_RECALL : NEW_AVG_RECALL,
    METRIC_F1_SCORE : NEW_AVG_F1_SCORE,
    METRIC_MCC : NEW_AVG_MCC,
    METRIC_JACCARD : NEW_AVG_JACCARD,
    METRIC_YOUDEN : NEW_AVG_YOUDEN,
    METRIC_ROCAUC : NEW_AVG_ROC_AUC
}

METRIC_LIST = [metric_name for _, metric_name in NEW_METRIC_NAME_TO_AVG_METRIC_FEATURE_NAME.items()]

MODEL_NAME_TO_COLOR = {
    NEW_MODEL_NAME_OCF_HAMMING: 'mediumblue',
    MODEL_NAME_LOGISTIC_REGRESSION: 'wheat',
    MODEL_NAME_SVM: 'yellowgreen',
    MODEL_NAME_DECISION_TREE: 'skyblue',
    MODEL_NAME_RANDOM_FOREST: 'saddlebrown',
    MODEL_NAME_GRADIENT_BOOSTING: 'coral',
    MODEL_NAME_NEURAL_NETWORK: 'orangered',
    MODEL_NAME_KNN: 'darkturquoise',
    MODEL_NAME_NAIVE_BAYES: 'greenyellow',
    MODEL_NAME_TRIVIAL_MAJ: 'grey'
}
UPDATED_NAMES_FOR_FIGURES = {
    AVG_ACCURACY: NEW_AVG_ACCURACY,
    AVG_F1_SCORE: NEW_AVG_F1_SCORE,
    AVG_PRECISION: NEW_AVG_PRECISION,
    AVG_RECALL: NEW_AVG_RECALL,
    AVG_JACCARD: NEW_AVG_JACCARD,
    AVG_MCC: NEW_AVG_MCC,
    AVG_YOUDEN: NEW_AVG_YOUDEN,
    AVG_ROC_AUC: NEW_AVG_ROC_AUC,
    MODEL_NAME_OCF_HAMMING: NEW_MODEL_NAME_OCF_HAMMING
}


# checks if a given results csv file has all necessary data
def has_all_necessary_results(df_results):
    # first check if all columns are present
    for feature_name in ALL_FEATURE_NAME_FOR_TEST_RESULTS:
        if feature_name not in df_results.columns:
            return False

    # now check if all models are present
    assert MODEL_NAME in df_results.columns

    for model_name in ALL_MODEL_NAMES:
        if model_name not in df_results[MODEL_NAME].values:
            return False

    return True


# Load all CSV result files into a list of DataFrames
def load_all_available_result_csv_files(all_dataset_names):
    all_available_results = {}

    for ds_name in all_ds_names:
        # Generate the file name for the dataset
        result_csv_file_name = get_all_results_file_name(ds_name)

        # Check if the file exists
        if Path(result_csv_file_name).exists():
            # Load the dataset
            df_all_results_dataset = my_from_csv(result_csv_file_name)

            # Verify if the dataset has all necessary results
            if has_all_necessary_results(df_all_results_dataset):
                # Add the dataset to the dictionary
                all_available_results[ds_name] = df_all_results_dataset

    return all_available_results


# I want 10 * 9 scatter plots, each comparing the results of my own custom model with the results of each of the
# other 9 models, over all 50 csv files. Additionally, I want an additional set of 9 scatter plots that take the
# average value of each metric over all 50 csv files
# The input all_results is a dictionary {dataset_name : all_results_for_this_dataset_as_a_csv_file}
def generate_scatter_plots_old(all_results):
    # Prepare data for scatter plots
    scatter_data = []

    for ds_name, df_results in all_results.items():
        df_ocfhamming = df_results[df_results[MODEL_NAME] == NEW_MODEL_NAME_OCF_HAMMING]
        for other_model_name in df_results[MODEL_NAME].unique():
            if other_model_name != NEW_MODEL_NAME_OCF_HAMMING:
                other_model = df_results[df_results[MODEL_NAME] == other_model_name]
                for metric in METRIC_LIST:
                    scatter_data.append({
                        NEW_MODEL_NAME_OCF_HAMMING: df_ocfhamming[metric].values[0],
                        "OtherModel": other_model[metric].values[0],
                        "Metric": metric,
                        "Model": other_model_name
                    })
    scatter_df = pd.DataFrame(scatter_data)

    # Generate scatter plots
    os.makedirs(get_all_results_plot_dir_path(), exist_ok=True)

    for metric in METRIC_LIST:
        for other_model_name in scatter_df["Model"].unique():
            plt.figure(figsize=(6, 6))
            data = scatter_df[(scatter_df["Metric"] == metric) & (scatter_df["Model"] == other_model_name)]
            plt.scatter(data[NEW_MODEL_NAME_OCF_HAMMING], data["OtherModel"], alpha=0.8)
            plt.plot([min(data[NEW_MODEL_NAME_OCF_HAMMING]), max(data[NEW_MODEL_NAME_OCF_HAMMING])],
                     [min(data[NEW_MODEL_NAME_OCF_HAMMING]), max(data[NEW_MODEL_NAME_OCF_HAMMING])], linestyle='--',
                     color='gray', linewidth=1)
            plt.xlabel(NEW_MODEL_NAME_OCF_HAMMING)
            plt.ylabel(other_model_name)
            plt.title(f"{metric} ({NEW_MODEL_NAME_OCF_HAMMING} vs {other_model_name})")
            plt.grid(True)
            plt.savefig(os.path.join(get_all_results_plot_dir_path(), f"scatter_{metric}_{other_model_name}.png"))
            plt.close()


def generate_scatter_plots(all_results):
    # Set global font sizes for the plot
    plt.rcParams.update({
        'axes.titlesize': 14,     # Title font size
        'axes.labelsize': 20,     # X and Y axis labels font size
        'xtick.labelsize': 20,    # X-axis tick font size
        'ytick.labelsize': 20,    # Y-axis tick font size
        'legend.fontsize': 20,    # Legend font size
    })

    # Prepare data for scatter plots
    scatter_data = []

    for ds_name, df_results in all_results.items():
        df_ocfhamming = df_results[df_results[MODEL_NAME] == NEW_MODEL_NAME_OCF_HAMMING]
        for other_model_name in df_results[MODEL_NAME].unique():
            if other_model_name != NEW_MODEL_NAME_OCF_HAMMING:
                other_model = df_results[df_results[MODEL_NAME] == other_model_name]
                for metric in METRIC_LIST:
                    scatter_data.append({
                        NEW_MODEL_NAME_OCF_HAMMING: df_ocfhamming[metric].values[0],
                        "OtherModel": other_model[metric].values[0],
                        "Metric": metric,
                        "Model": other_model_name
                    })
    scatter_df = pd.DataFrame(scatter_data)

    # Generate scatter plots
    os.makedirs(get_all_results_plot_dir_path(), exist_ok=True)

    for metric in METRIC_LIST:
        for other_model_name in scatter_df["Model"].unique():
            plt.figure(figsize=(8, 8))  # Increase figure size
            data = scatter_df[(scatter_df["Metric"] == metric) & (scatter_df["Model"] == other_model_name)]
            plt.scatter(data[NEW_MODEL_NAME_OCF_HAMMING], data["OtherModel"], alpha=0.8, s=150)
            plt.plot([min(data[NEW_MODEL_NAME_OCF_HAMMING]), max(data[NEW_MODEL_NAME_OCF_HAMMING])],
                     [min(data[NEW_MODEL_NAME_OCF_HAMMING]), max(data[NEW_MODEL_NAME_OCF_HAMMING])], linestyle='--',
                     color='gray', linewidth=1)
            plt.xlabel(NEW_MODEL_NAME_OCF_HAMMING, fontsize=20)  # X-axis label font size
            plt.ylabel(other_model_name, fontsize=20)  # Y-axis label font size
            plt.title(f"{metric} ({NEW_MODEL_NAME_OCF_HAMMING} vs {other_model_name})", fontsize=20, y=1.01)  # Title font size
            plt.grid(True)
            plt.xticks(fontsize=20)  # X-axis tick font size
            plt.yticks(fontsize=20)  # Y-axis tick font size
            plt.savefig(os.path.join(get_all_results_plot_dir_path(), f"scatter_{metric}_{other_model_name}.png"))
            plt.close()


def generate_box_plots(all_results):
    # Set global font sizes for the plot
    plt.rcParams.update({
        'axes.titlesize': 18,  # Title font size
        'axes.labelsize': 16,  # X and Y axis labels font size
        'xtick.labelsize': 16,  # X-axis tick font size
        'ytick.labelsize': 16,  # Y-axis tick font size
        'legend.fontsize': 16,  # Legend font size
    })

    for metric in METRIC_LIST:
        # Combine all results into a single DataFrame
        combined_df = pd.concat(all_results.values(), ignore_index=True)

        # Map the model names to their short names using the MODEL_SHORT_NAMES dictionary
        combined_df[MODEL_NAME] = combined_df[MODEL_NAME].map(MODEL_SHORT_NAMES)

        # Ensure there are no duplicate labels (column names)
        combined_df = combined_df.loc[:, ~combined_df.columns.duplicated()]

        # Create the box plot
        plt.figure(figsize=(14, 8))  # Increase figure size
        sns.boxplot(
            x=MODEL_NAME,
            y=metric,
            data=combined_df,
            order=combined_df[MODEL_NAME].dropna().unique()  # Avoid issues with NaN
        )
        plt.title(f"Box Plot: {metric}", fontsize=16)  # Specific font size for the title
        plt.xlabel("Model Name", fontsize=16)  # X-axis label font size
        plt.ylabel(metric, fontsize=16)  # Y-axis label font size
        plt.xticks(rotation=45, fontsize=16)  # X-axis tick font size
        plt.yticks(fontsize=16)  # Y-axis tick font size
        plt.grid(axis="y")
        plt.subplots_adjust(bottom=0.23)  # Add space below the figure
        plt.savefig(os.path.join(get_all_results_plot_dir_path(), f"box_{metric}.png"))
        plt.close()

# Function to create a radar chart
def make_spider_chart(categories, values, label, ax, model_name):
    N = len(categories)
    angles = [n / float(N) * 2 * pi for n in range(N)]
    angles += angles[:1]

    ax.set_theta_offset(pi / 2)
    ax.set_theta_direction(-1)

    plt.xticks(angles[:-1], categories, fontsize=18)

    # Define colors and styles
    color = MODEL_NAME_TO_COLOR[model_name]
    line_width = 2
    line_style = 'solid'
    if model_name == NEW_MODEL_NAME_OCF_HAMMING:
        line_width = 3
    elif model_name == MODEL_NAME_TRIVIAL_MAJ:
        line_style = 'dashed'

    ax.plot(angles, values, linewidth=line_width, linestyle=line_style, label=label, color=color)
    ax.fill(angles, values, color, alpha=0.1)

    # Increase font size for legend
    ax.legend(fontsize=18)

    # Increase font size for tick labels (values on radial axis)
    for label in ax.get_yticklabels():
        label.set_fontsize(20)


# Prepare spider plots for datasets
def generate_spider_plots(all_results):
    # Helper function to split models into two parts
    def split_models(df_results):
        focus_model = df_results[df_results[MODEL_NAME] == NEW_MODEL_NAME_OCF_HAMMING]
        trivial_model = df_results[df_results[MODEL_NAME] == MODEL_NAME_TRIVIAL_MAJ]
        other_models = df_results[
            (df_results[MODEL_NAME] != NEW_MODEL_NAME_OCF_HAMMING) & (df_results[MODEL_NAME] != MODEL_NAME_TRIVIAL_MAJ)]

        # Split other models into two parts
        midpoint = len(other_models) // 2
        part1_other = other_models.iloc[:midpoint]
        part2_other = other_models.iloc[midpoint:]

        # Ensure correct composition
        part1 = pd.concat([part1_other, focus_model])
        part2 = pd.concat([part2_other, trivial_model, focus_model])

        return part1, part2

    # Process each dataset
    for ds_name, df_results in all_results.items():
        # Split into two parts
        part1, part2 = split_models(df_results)

        for idx, part in enumerate([part1, part2], start=1):
            plt.figure(figsize=(8, 8))
            ax = plt.subplot(111, polar=True)

            # Draw models in the specified order
            models_to_draw = part[MODEL_NAME].tolist()
            if MODEL_NAME_TRIVIAL_MAJ in models_to_draw:
                models_to_draw.remove(MODEL_NAME_TRIVIAL_MAJ)
            if NEW_MODEL_NAME_OCF_HAMMING in models_to_draw:
                models_to_draw.remove(NEW_MODEL_NAME_OCF_HAMMING)

            # Draw other models first
            for model_name in models_to_draw:
                row = part[part[MODEL_NAME] == model_name].iloc[0]
                values = [row[metric] for metric in METRIC_LIST]
                values += values[:1]
                make_spider_chart(METRIC_LIST, values, model_name, ax, model_name)

            # Draw TRIVIAL_MAJ second last (only in part2)
            if idx == 2 and MODEL_NAME_TRIVIAL_MAJ in part[MODEL_NAME].values:
                row = part[part[MODEL_NAME] == MODEL_NAME_TRIVIAL_MAJ].iloc[0]
                values = [row[metric] for metric in METRIC_LIST]
                values += values[:1]
                make_spider_chart(METRIC_LIST, values, MODEL_NAME_TRIVIAL_MAJ, ax, MODEL_NAME_TRIVIAL_MAJ)

            # Draw OCF_HAMMING last (in both parts)
            if NEW_MODEL_NAME_OCF_HAMMING in part[MODEL_NAME].values:
                row = part[part[MODEL_NAME] == NEW_MODEL_NAME_OCF_HAMMING].iloc[0]
                values = [row[metric] for metric in METRIC_LIST]
                values += values[:1]
                make_spider_chart(METRIC_LIST, values, NEW_MODEL_NAME_OCF_HAMMING, ax, NEW_MODEL_NAME_OCF_HAMMING)

            # Set title and legend
            plt.title(f"{ds_name} (#{idx})", fontsize=18)
            handles, labels = ax.get_legend_handles_labels()

            # Reorder legend: OCF_HAMMING first, TRIVIAL_MAJ last
            if idx == 2:
                order = ([labels.index(NEW_MODEL_NAME_OCF_HAMMING)] +
                         [i for i, lbl in enumerate(labels) if
                          lbl not in [NEW_MODEL_NAME_OCF_HAMMING, MODEL_NAME_TRIVIAL_MAJ]] +
                         [labels.index(MODEL_NAME_TRIVIAL_MAJ)])
            else:
                order = ([labels.index(NEW_MODEL_NAME_OCF_HAMMING)] +
                         [i for i, lbl in enumerate(labels) if lbl != NEW_MODEL_NAME_OCF_HAMMING])

            plt.legend([handles[i] for i in order], [labels[i] for i in order], loc="upper right",
                       bbox_to_anchor=(1.5, 1.1), fontsize=18)

            # Save figure
            plt.savefig(os.path.join(get_all_results_plot_dir_path(), f"spider_dataset_{ds_name}-part{idx}.png"))
            plt.close()

    # Generate average radar chart
    avg_df = pd.concat(all_results.values()).groupby(MODEL_NAME).mean().reset_index()
    part1, part2 = split_models(avg_df)

    for idx, part in enumerate([part1, part2], start=1):
        plt.figure(figsize=(13, 8))
        ax = plt.subplot(111, polar=True)

        # Draw models in the specified order
        models_to_draw = part[MODEL_NAME].tolist()
        if MODEL_NAME_TRIVIAL_MAJ in models_to_draw:
            models_to_draw.remove(MODEL_NAME_TRIVIAL_MAJ)
        if NEW_MODEL_NAME_OCF_HAMMING in models_to_draw:
            models_to_draw.remove(NEW_MODEL_NAME_OCF_HAMMING)

        # Draw other models first
        for model_name in models_to_draw:
            row = part[part[MODEL_NAME] == model_name].iloc[0]
            values = [row[metric] for metric in METRIC_LIST]
            values += values[:1]
            make_spider_chart(METRIC_LIST, values, model_name, ax, model_name)

        # Draw TRIVIAL_MAJ second last (only in part2)
        if idx == 2 and MODEL_NAME_TRIVIAL_MAJ in part[MODEL_NAME].values:
            row = part[part[MODEL_NAME] == MODEL_NAME_TRIVIAL_MAJ].iloc[0]
            values = [row[metric] for metric in METRIC_LIST]
            values += values[:1]
            make_spider_chart(METRIC_LIST, values, MODEL_NAME_TRIVIAL_MAJ, ax, MODEL_NAME_TRIVIAL_MAJ)

        # Draw OCF_HAMMING last (in both parts)
        if NEW_MODEL_NAME_OCF_HAMMING in part[MODEL_NAME].values:
            row = part[part[MODEL_NAME] == NEW_MODEL_NAME_OCF_HAMMING].iloc[0]
            values = [row[metric] for metric in METRIC_LIST]
            values += values[:1]
            make_spider_chart(METRIC_LIST, values, NEW_MODEL_NAME_OCF_HAMMING, ax, NEW_MODEL_NAME_OCF_HAMMING)

        # Set title and legend
        plt.title(f"Spider Plot: Average Results (Part {idx})", fontsize=18)
        handles, labels = ax.get_legend_handles_labels()

        # Reorder legend: OCF_HAMMING first, TRIVIAL_MAJ last
        if idx == 2:
            order = ([labels.index(NEW_MODEL_NAME_OCF_HAMMING)] +
                     [i for i, lbl in enumerate(labels) if
                      lbl not in [NEW_MODEL_NAME_OCF_HAMMING, MODEL_NAME_TRIVIAL_MAJ]] +
                     [labels.index(MODEL_NAME_TRIVIAL_MAJ)])
        else:
            order = ([labels.index(NEW_MODEL_NAME_OCF_HAMMING)] +
                     [i for i, lbl in enumerate(labels) if lbl != NEW_MODEL_NAME_OCF_HAMMING])

        plt.legend([handles[i] for i in order], [labels[i] for i in order], loc="upper right",
                   bbox_to_anchor=(1.5, 1.1), fontsize=18)

        # Save figure
        plt.savefig(os.path.join(get_all_results_plot_dir_path(), f"spider_avg-part{idx}.png"))
        plt.close()


# Function to select diverse datasets based on the comparison metric
def select_small_dataset_subset(all_results, subset_size, selected_metrics):
    """
    Selects a small subset of datasets where MODEL_NAME_OCF_HAMMING performs best, worst, and average
    relative to the remaining models, based on the specified metrics.

    Parameters:
        all_results (dict): A dictionary where keys are dataset names and values are DataFrames
                            containing models and their metric values.
        subset_size (int): Desired size of the subset of dataset names.
        selected_metrics (list): List of metrics to consider for comparison.

    Returns:
        list: A small subset of dataset names selected based on clustering.
    """
    # Prepare a DataFrame to store performance differences for clustering
    dataset_differences = []

    for dataset_name, dataset in all_results.items():
        # Ensure the dataset contains the required metrics
        if all(metric in dataset.columns for metric in selected_metrics):
            # Calculate the average values for all models except MODEL_NAME_OCF_HAMMING
            other_models = dataset[dataset[MODEL_NAME] != NEW_MODEL_NAME_OCF_HAMMING]
            avg_other_models = other_models[selected_metrics].mean()

            # Extract the values for MODEL_NAME_OCF_HAMMING
            ocf_values = dataset.loc[dataset[MODEL_NAME] == NEW_MODEL_NAME_OCF_HAMMING, selected_metrics].iloc[0]

            # Calculate the difference
            differences = ocf_values - avg_other_models

            # Append the results for this dataset
            dataset_differences.append((dataset_name, differences.values))

    # Convert differences to a DataFrame for clustering
    differences_df = pd.DataFrame(
        {name: diff for name, diff in dataset_differences}
    ).T
    differences_df.columns = selected_metrics

    # Normalize the data for clustering
    normalized_data = (differences_df - differences_df.min()) / (differences_df.max() - differences_df.min())

    # Apply KMeans clustering
    kmeans = KMeans(n_clusters=subset_size, random_state=42)
    differences_df['cluster'] = kmeans.fit_predict(normalized_data)

    # Select one dataset from each cluster (e.g., the dataset closest to the cluster center)
    selected_datasets = []
    for cluster in range(subset_size):
        cluster_data = differences_df[differences_df['cluster'] == cluster]
        center = kmeans.cluster_centers_[cluster]
        closest_idx = ((cluster_data[selected_metrics] - center) ** 2).sum(axis=1).idxmin()
        selected_datasets.append(closest_idx)

    return selected_datasets


if __name__ == "__main__":
    all_ds_names = sorted_by_increasing_size(get_all_datasets_names())
    all_res = load_all_available_result_csv_files(all_ds_names)
    # Iterate through each DataFrame in all_res.values()
    for df in all_res.values():
        # Replace column names
        df.rename(columns=UPDATED_NAMES_FOR_FIGURES, inplace=True)
        # Replace values inside the DataFrame
        for old_value, new_value in UPDATED_NAMES_FOR_FIGURES.items():
            df.replace(to_replace=old_value, value=new_value, inplace=True)
    print(f'Results available for {len(all_res)} datasets:')
    print(all_res.keys())
    with pd.option_context('display.max_columns', None):
        print(all_res.values())

    #generate_scatter_plots(all_res)
    #generate_box_plots(all_res)
    generate_spider_plots(all_res)

    # Select diverse datasets
    # Desired subset size and metrics
    #subset_size = 3
    #selected_metrics = [NEW_AVG_YOUDEN]

    # Call the function
    #selected_datasets = select_small_dataset_subset(all_res, subset_size, selected_metrics)
    #print("Selected dataset names:", selected_datasets)
