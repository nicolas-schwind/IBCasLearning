import os
import pandas as pd
import matplotlib.pyplot as plt
from math import pi
from constants import *
from dataop import my_from_csv, get_nb_rows, get_nb_features, sorted_by_increasing_size
from to_file import get_dataset_dir_path, get_dataset_file_path, get_all_datasets_names


def from_result_csv_to_plot(dataset_name, result_dataset, result_fig_file_1, result_fig_file_2, focus_model):
    initial_dataset = my_from_csv(get_dataset_file_path(dataset_name), remove_first_column=False)
    nb_pos = get_nb_rows(initial_dataset[initial_dataset['y'] == 1])
    nb_neg = get_nb_rows(initial_dataset[initial_dataset['y'] == 0])
    nb_features = get_nb_features(initial_dataset)

    df = pd.read_csv(result_dataset)

    # Normalize AVG_MCC and AVG_YOUDEN
    df[AVG_MCC] = (df[AVG_MCC] + 1) / 2
    df[AVG_YOUDEN] = (df[AVG_YOUDEN] + 1) / 2

    # Features to include in the radar chart
    avg_mcc_label = "AVG_MCC\n(onto [0,1])"
    avg_youden_label = "AVG_YOUDEN\n(onto [0,1])"
    features_to_include = [avg_mcc_label, avg_youden_label, AVG_JACCARD, AVG_ACCURACY, AVG_F1_SCORE, AVG_PRECISION, AVG_RECALL, AVG_ROC_AUC]

    # Rename AVG_MCC column to indicate normalization
    df.rename(columns={AVG_MCC: avg_mcc_label}, inplace=True)
    df.rename(columns={AVG_YOUDEN: avg_youden_label}, inplace=True)

    # Number of variables
    num_vars = len(features_to_include)

    # Compute angle for each axis
    angles = [n / float(num_vars) * 2 * pi for n in range(num_vars)]
    angles += angles[:1]

    # Find the focus model row
    focus_row = df[df[MODEL_NAME] == focus_model].iloc[0]
    other_models = df[df[MODEL_NAME] != focus_model]

    # Split other models into two halves
    split_index = len(other_models) // 2
    other_models_1 = other_models.iloc[:split_index]
    other_models_2 = other_models.iloc[split_index:]

    def plot_radar_chart(df, focus_row, file_name):
        fig, ax = plt.subplots(figsize=(10, 8), subplot_kw=dict(polar=True))

        # Plot each model's data
        handles = []
        labels = []
        for i, row in df.iterrows():
            values = row[features_to_include].tolist()
            values += values[:1]
            handle, = ax.plot(angles, values, label=row[MODEL_NAME], linewidth=2)
            ax.fill(angles, values, alpha=0.1)
            handles.append(handle)
            labels.append(row[MODEL_NAME])

        # Plot the focus model's data with emphasis
        focus_values = focus_row[features_to_include].tolist()
        focus_values += focus_values[:1]
        focus_handle, = ax.plot(angles, focus_values, label=focus_model, linewidth=3.5, color='red')
        ax.fill(angles, focus_values, alpha=0.3, color='red')

        # Add the focus model to the top of the legend
        handles = [focus_handle] + handles
        labels = [focus_model] + labels

        # Add the feature labels to the radar chart
        plt.xticks(angles[:-1], features_to_include, color='grey', size=12)

        # Draw y-labels and set range
        plt.yticks([0.1, 0.2, 0.4, 0.6, 0.8, 1], ["0.1", "0.2", "0.4", "0.6", "0.8", "1"], color="grey", size=10)
        plt.ylim(0, 1)

        # Add a title
        fig_title = f'Model Perf for {dataset_name} ({nb_pos} pos / {nb_neg} neg / {nb_features} feat)'
        plt.title(fig_title, size=15, color='grey', y=1.1)

        # Add a legend
        plt.legend(handles=handles, labels=labels, loc='upper right', bbox_to_anchor=(1.3, 1.1))

        # Save the figure
        plt.savefig(file_name)
        plt.close(fig)

    # Plot and save the radar charts
    plot_radar_chart(other_models_1, focus_row, result_fig_file_1)
    plot_radar_chart(other_models_2, focus_row, result_fig_file_2)


if __name__ == "__main__":
    all_dataset_names = sorted_by_increasing_size(get_all_datasets_names())
    #all_dataset_names = [DATASET_NAME_TEST_MAJORITY2]
    for dataset_name in all_dataset_names:
        dataset_results_file_name = get_dataset_dir_path(dataset_name) + '/' + dataset_name + ALL_RESULTS + '.csv'
        if not os.path.exists(dataset_results_file_name):
            print(f'No result available for dataset {dataset_name} (the file {dataset_results_file_name} does not exist)')
            continue
        fig_results_file_name1 = get_dataset_dir_path(dataset_name) + '/' + dataset_name + ALL_RESULTS + '-part1.png'
        fig_results_file_name2 = get_dataset_dir_path(dataset_name) + '/' + dataset_name + ALL_RESULTS + '-part2.png'
        from_result_csv_to_plot(dataset_name, dataset_results_file_name, fig_results_file_name1, fig_results_file_name2, MODEL_NAME_OCF_HAMMING)
        print(f'Plot for dataset {dataset_name} created! Available in files {fig_results_file_name1} and {fig_results_file_name2}')
