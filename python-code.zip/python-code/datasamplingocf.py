import os
import re
from datadistances import convert_from_distances_to_ocf_to_remove, get_dataset_with_distances

DATASET_PATH = 'datasets'
DATASET_OCF_NAME = '-ocf'
DATASET_SAMPLE_PATH = '-sample'
DATASET_SAMPLE_TRAIN_NAME = '-train'
DATASET_SAMPLE_TEST_NAME = '-test'

def get_datasetwithocf_filename(dataset_name):
    return dataset_name + DATASET_OCF_NAME + '.csv'


def get_new_sample_pathname(dataset_name, test_size=0.1):
    # List directory names
    directory_names = os.listdir(DATASET_PATH + '/' + dataset_name)

    #return DATASET_PATH + '/' + dataset_name + DATASET_SAMPLE_PATH + '-' + test_size


def get_sample_test_filename(dataset_name, test_size=0.1)


def to_datasetwithocf(initial_dataset, distance_function):
    return convert_from_distances_to_ocf_to_remove(get_dataset_with_distances(
        initial_dataset, distance_function=distance_function))


def datasetwithocf_to_file(datasetwithocf, dataset_name):
    dir_name = dataset_name + ''


def sampling(initial_dataset, test_size=0.1, nb_sampling_steps=1):
