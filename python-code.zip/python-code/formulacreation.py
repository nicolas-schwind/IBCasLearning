from pysat.pb import *


# return a formula with unit clauses
def add_data_clauses(formula, dataset):
    for i, row in dataset.iterrows():
        for col_name in dataset.columns:
            value = int(row[col_name])
            formula.append([value])


def add_counters_clauses(formula, nb_rows, nb_cols):
    counter_variable = (nb_rows + 1) * nb_cols
    for i in range(nb_rows):
        for j in range(nb_cols):
            a = int(1 + ((i + 1) * nb_cols) + j)
            b = int(1 + j)
            c = int(a + (nb_rows * nb_cols))
            formula.append([a, -b, c])
            formula.append([-a, b, c])
            formula.append([a, b, -c])
            formula.append([-a, -b, -c])


def add_pb_clauses_leq(formula, nb_rows, nb_cols, k):
    literals = [(1 + ((nb_rows + 1) * nb_cols) + i) for i in range(nb_rows * nb_cols)]
    pb_formula = PBEnc.leq(lits=literals, bound=k)
    formula.extend(pb_formula.clauses)


def add_pb_clauses_geq(formula, nb_rows, nb_cols, k):
    literals = [(1 + ((nb_rows + 1) * nb_cols) + i) for i in range(nb_rows * nb_cols)]
    pb_formula = PBEnc.geq(lits=literals, bound=k)
    formula.extend(pb_formula.clauses)
